import LoginForm from "@/src/components/login-form"

export default function LoginPage() {
  return <LoginForm />
}



