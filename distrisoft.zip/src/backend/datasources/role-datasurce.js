import { prisma } from '@/prisma/client';


export default class RoleDatasource {
  constructor(model) {
    super(model);
  }
}